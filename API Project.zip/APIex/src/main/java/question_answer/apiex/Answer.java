package question_answer.apiex;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Answer {
	
	@Id
	@Column(name="answer_id")
	private int answe_id;
	private String answer;
	
	
	public Answer()
	{
		super();
	}

	public Answer(int answe_id, String answer) {
		super();
		this.answe_id = answe_id;
		this.answer = answer;
		
	}
	public int getAnswe_id() {
		return answe_id;
	}
	public void setAnswe_id(int answe_id) {
		this.answe_id = answe_id;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	@Override
	public String toString() {
		return "Answer [answe_id=" + answe_id + ", answer=" + answer + "]";
	}
	
	

}
